import { integer, pgTable, serial, text, timestamp, varchar } from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  /** Stable public identifier stored in the session cookie. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }).unique(),
  loginMethod: varchar("loginMethod", { length: 64 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  role: varchar("role", { length: 16, enum: ["user", "admin"] }).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export const billEntries = pgTable("bill_entries", {
  id: varchar("id", { length: 36 }).primaryKey(),
  entryNo: varchar("entryNo", { length: 16 }).notNull().unique(),
  invoiceNo: varchar("invoiceNo", { length: 128 }).notNull(),
  invoiceDate: varchar("invoiceDate", { length: 10 }).notNull(),
  vendor: text("vendor").notNull(),
  details: text("details").notNull(),
  amount: integer("amount").notNull().default(0),
  entryDate: varchar("entryDate", { length: 10 }).notNull(),
  time: varchar("time", { length: 5 }).notNull(),
  name: varchar("name", { length: 160 }).notNull(),
  status: varchar("status", { length: 16, enum: ["received", "pending", "not-received"] }).notNull().default("pending"),
  createdByOpenId: varchar("createdByOpenId", { length: 64 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull(),
});

export type BillEntry = typeof billEntries.$inferSelect;
export type InsertBillEntry = typeof billEntries.$inferInsert;

export const billRegisterMeta = pgTable("bill_register_meta", {
  metaKey: varchar("metaKey", { length: 64 }).primaryKey(),
  metaValue: text("metaValue").notNull(),
});
