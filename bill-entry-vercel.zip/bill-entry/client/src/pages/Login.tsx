import { FormEvent, useState } from "react";
import { trpc } from "@/lib/trpc";

export default function Login() {
  const utils = trpc.useUtils();
  const [mode, setMode] = useState<"login" | "register">("login");
  const [form, setForm] = useState({ name: "", email: "", password: "", inviteCode: "" });
  const [error, setError] = useState("");
  const onSuccess = () => utils.auth.me.invalidate();
  const onError = (e: { message: string }) => setError(e.message);
  const login = trpc.auth.login.useMutation({ onSuccess, onError });
  const register = trpc.auth.register.useMutation({ onSuccess, onError });
  const busy = login.isPending || register.isPending;
  const set = (key: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [key]: e.target.value });

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setError("");
    if (mode === "login") login.mutate({ email: form.email, password: form.password });
    else register.mutate(form);
  };

  return (
    <main className="auth-screen">
      <form className="auth-card auth-form" onSubmit={submit}>
        <div className="brand-mark auth-brand-mark">▤</div>
        <span className="eyebrow">Shared organization ledger</span>
        <h1>{mode === "login" ? "Sign in to bill entry" : "Create your account"}</h1>
        {mode === "register" && <input className="form-input" placeholder="Full name" autoComplete="name" value={form.name} onChange={set("name")} required />}
        <input className="form-input" type="email" placeholder="Email" autoComplete="email" value={form.email} onChange={set("email")} required />
        <input className="form-input" type="password" placeholder="Password (8+ characters)" autoComplete={mode === "login" ? "current-password" : "new-password"} minLength={mode === "register" ? 8 : undefined} value={form.password} onChange={set("password")} required />
        {mode === "register" && <input className="form-input" placeholder="Invite code from your admin" value={form.inviteCode} onChange={set("inviteCode")} required />}
        {error && <p className="auth-error" role="alert">{error}</p>}
        <button className="primary-button auth-login-button" type="submit" disabled={busy}>{busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}</button>
        <button type="button" className="auth-switch" onClick={() => { setError(""); setMode(mode === "login" ? "register" : "login"); }}>
          {mode === "login" ? "New here? Create an account" : "Already have an account? Sign in"}
        </button>
      </form>
    </main>
  );
}
