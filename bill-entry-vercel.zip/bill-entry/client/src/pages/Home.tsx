import {
  Archive,
  ArrowDownToLine,
  ArrowUpRight,
  Bell,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  CircleDashed,
  Clock3,
  CloudUpload,
  Download,
  FileCheck2,
  FileSpreadsheet,
  FileText,
  FileScan,
  Files,
  LayoutDashboard,
  Menu,
  MoreHorizontal,
  Plus,
  ReceiptText,
  ScanLine,
  Search,
  Settings2,
  SlidersHorizontal,
  Sparkles,
  Trash2,
  Upload,
  UserRound,
  X,
  Zap,
} from "lucide-react";
import { ChangeEvent, FormEvent, useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

type BillStatus = "received" | "pending" | "not-received";
type FilterKey = "all" | BillStatus;

type BillRecord = {
  id: string;
  entryNo: string;
  invoiceNo: string;
  invoiceDate: string;
  vendor: string;
  details: string;
  amount: number;
  entryDate: string;
  time: string;
  name: string;
  status: BillStatus;
};

type BillDraft = Omit<BillRecord, "id">;

type ScannedBillResponse = {
  invoiceNo: string;
  invoiceDate: string;
  vendor: string;
  details: string;
  amount: number;
  entryDate: string;
  time: string;
  name: string;
  status: BillStatus;
  confidence: "high" | "medium" | "low";
  notes: string;
};

const toBillRecord = (record: BillRecord): BillRecord => ({
  ...record,
  amount: Number(record.amount || 0),
});

const statusMeta: Record<BillStatus, { label: string; shortLabel: string; tone: string; icon: typeof CheckCircle2 }> = {
  received: { label: "Received", shortLabel: "Received", tone: "status-received", icon: CheckCircle2 },
  pending: { label: "Pending", shortLabel: "Pending", tone: "status-pending", icon: Clock3 },
  "not-received": { label: "Not received", shortLabel: "Not received", tone: "status-not-received", icon: CircleDashed },
};

const formatAmount = (amount: number) =>
  new Intl.NumberFormat("en-MV", { style: "currency", currency: "MVR", maximumFractionDigits: 0 }).format(amount);

const formatDate = (date: string) => {
  if (!date) return "—";
  return new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", year: "numeric" }).format(
    new Date(`${date}T00:00:00`),
  );
};

const today = () => new Date().toISOString().slice(0, 10);
const currentTime = () => new Date().toTimeString().slice(0, 5);

const emptyDraft = (entryNo: string): BillDraft => ({
  entryNo,
  invoiceNo: "",
  invoiceDate: today(),
  vendor: "",
  details: "",
  amount: 0,
  entryDate: today(),
  time: currentTime(),
  name: "Aminath Nafha",
  status: "pending",
});

function StatusPill({ status, compact = false }: { status: BillStatus; compact?: boolean }) {
  const meta = statusMeta[status];
  const Icon = meta.icon;
  return (
    <span className={`status-pill ${meta.tone} ${compact ? "status-compact" : ""}`}>
      <Icon size={compact ? 12 : 13} strokeWidth={2.2} />
      {meta.shortLabel}
    </span>
  );
}

function Field({
  label,
  children,
  helper,
  className = "",
}: {
  label: string;
  children: React.ReactNode;
  helper?: string;
  className?: string;
}) {
  return (
    <label className={`field ${className}`}>
      <span className="field-label">{label}</span>
      {children}
      {helper ? <span className="field-helper">{helper}</span> : null}
    </label>
  );
}

async function photoToScanDataUrl(file: File, maxSide = 1800): Promise<string> {
  const bitmap = await createImageBitmap(file);
  const scale = Math.min(1, maxSide / Math.max(bitmap.width, bitmap.height));
  const canvas = document.createElement("canvas");
  canvas.width = Math.round(bitmap.width * scale);
  canvas.height = Math.round(bitmap.height * scale);
  canvas.getContext("2d")!.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
  bitmap.close();
  return canvas.toDataURL("image/jpeg", 0.85);
}

export default function Home() {
  const billsQuery = trpc.bills.list.useQuery(undefined, { refetchInterval: 10000, refetchOnWindowFocus: true });
  const meQuery = trpc.auth.me.useQuery();
  const createBill = trpc.bills.create.useMutation();
  const updateBill = trpc.bills.update.useMutation();
  const changeBillStatus = trpc.bills.changeStatus.useMutation();
  const deleteBill = trpc.bills.delete.useMutation();
  const logout = trpc.auth.logout.useMutation({ onSuccess: () => window.location.reload() });
  const [records, setRecords] = useState<BillRecord[]>([]);
  const userName = meQuery.data?.name || meQuery.data?.email || "Signed-in user";
  const userInitials = userName.split(/\s+/).map(part => part[0]).join("").slice(0, 2).toUpperCase() || "U";
  const [filter, setFilter] = useState<FilterKey>("all");
  const [search, setSearch] = useState("");
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState<BillDraft>(() => emptyDraft("007/2026"));
  const [isScanning, setIsScanning] = useState(false);
  const [scanNotes, setScanNotes] = useState("");
  const [isMobileNavOpen, setIsMobileNavOpen] = useState(false);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const photoInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (billsQuery.data) setRecords(billsQuery.data.map(record => toBillRecord(record as BillRecord)));
  }, [billsQuery.data]);

  const nextEntryNo = useMemo(() => {
    const year = new Date().getFullYear();
    const max = records.reduce((highest, item) => {
      const [number, recordYear] = item.entryNo.split("/");
      if (Number(recordYear) !== year) return highest;
      return Math.max(highest, Number(number) || 0);
    }, 0);
    return `${String(max + 1).padStart(3, "0")}/${year}`;
  }, [records]);

  const counts = useMemo(
    () => ({
      all: records.length,
      received: records.filter(item => item.status === "received").length,
      pending: records.filter(item => item.status === "pending").length,
      "not-received": records.filter(item => item.status === "not-received").length,
    }),
    [records],
  );

  const totalAmount = useMemo(() => records.reduce((sum, item) => sum + Number(item.amount || 0), 0), [records]);

  const filteredRecords = useMemo(() => {
    const normalized = search.trim().toLowerCase();
    return records
      .filter(item => filter === "all" || item.status === filter)
      .filter(item => {
        if (!normalized) return true;
        return [item.entryNo, item.invoiceNo, item.vendor, item.details, item.name]
          .join(" ")
          .toLowerCase()
          .includes(normalized);
      })
      .sort((a, b) => b.entryNo.localeCompare(a.entryNo, undefined, { numeric: true }));
  }, [filter, records, search]);

  const openNewEntry = (prefill?: Partial<BillDraft>) => {
    setEditingId(null);
    setScanNotes("");
    setDraft({ ...emptyDraft(nextEntryNo), ...prefill, entryNo: nextEntryNo });
    setIsFormOpen(true);
  };

  const openEditEntry = (record: BillRecord) => {
    const { id: _id, ...recordDraft } = record;
    setEditingId(record.id);
    setScanNotes("");
    setDraft(recordDraft);
    setIsFormOpen(true);
  };

  const closeForm = () => {
    if (isScanning) return;
    setIsFormOpen(false);
    setEditingId(null);
  };

  const updateDraft = <K extends keyof BillDraft>(key: K, value: BillDraft[K]) => {
    setDraft(current => ({ ...current, [key]: value }));
  };

  const saveEntry = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!draft.invoiceNo.trim() || !draft.vendor.trim()) {
      toast.error("Add an invoice number and vendor before saving.");
      return;
    }
    const { entryNo: _entryNo, ...fields } = draft;
    try {
      if (editingId) {
        const saved = await updateBill.mutateAsync({ id: editingId, fields });
        if (saved) setRecords(current => current.map(item => (item.id === editingId ? toBillRecord(saved as BillRecord) : item)));
        toast.success("Bill entry updated for everyone");
      } else {
        const saved = await createBill.mutateAsync(fields);
        setRecords(current => [toBillRecord(saved as BillRecord), ...current]);
        toast.success(`${saved.entryNo} added to the shared register`);
      }
      setIsFormOpen(false);
      setEditingId(null);
      void billsQuery.refetch();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not save this bill entry.");
    }
  };

  const changeStatus = async (id: string, status: BillStatus) => {
    setRecords(current => current.map(item => (item.id === id ? { ...item, status } : item)));
    try {
      await changeBillStatus.mutateAsync({ id, status });
      toast.success(`Bill marked ${statusMeta[status].label.toLowerCase()}`);
    } catch (error) {
      void billsQuery.refetch();
      toast.error(error instanceof Error ? error.message : "Could not update the bill status.");
    }
  };

  const deleteEntryById = async (id: string) => {
    const entry = records.find(item => item.id === id);
    if (!entry) return;
    if (!window.confirm(`Delete bill entry ${entry.entryNo}? This cannot be undone.`)) return;
    try {
      await deleteBill.mutateAsync({ id });
      setRecords(current => current.filter(item => item.id !== id));
      if (editingId === id) {
        setIsFormOpen(false);
        setEditingId(null);
      }
      toast.success(`${entry.entryNo} deleted from the shared register`);
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not delete this bill entry.");
    }
  };

  const deleteEntry = () => {
    if (editingId) void deleteEntryById(editingId);
  };

  const runScan = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Please upload a photo of the bill in JPG, PNG, or WebP format.");
      event.target.value = "";
      return;
    }
    setIsScanning(true);
    setIsFormOpen(true);
    setEditingId(null);
    setDraft(emptyDraft(nextEntryNo));
    setScanNotes("");
    try {
      const dataUrl = await photoToScanDataUrl(file);
      const response = await fetch("/api/scan-bill", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ dataUrl, fileName: file.name }),
      });
      const payload = await response.json() as { bill?: ScannedBillResponse; error?: string };
      if (!response.ok || !payload.bill) throw new Error(payload.error || "Unable to read this bill photo.");
      const scanned = payload.bill;
      setDraft({
        ...emptyDraft(nextEntryNo),
        invoiceNo: scanned.invoiceNo,
        invoiceDate: scanned.invoiceDate || today(),
        vendor: scanned.vendor,
        details: scanned.details,
        amount: scanned.amount,
        entryDate: scanned.entryDate || today(),
        time: scanned.time || currentTime(),
        name: scanned.name || "Aminath Nafha",
        status: scanned.status,
      });
      setScanNotes(`${scanned.confidence[0].toUpperCase()}${scanned.confidence.slice(1)} confidence${scanned.notes ? ` · ${scanned.notes}` : ""}`);
      toast.success("Bill photo read — review the extracted details");
    } catch (error) {
      setIsFormOpen(false);
      const message = error instanceof Error ? error.message : "Unable to read this bill photo.";
      toast.error(message);
    } finally {
      setIsScanning(false);
    }
    event.target.value = "";
  };

  const exportHeaders = [
      "Entry no.",
      "Invoice no.",
      "Invoice date",
      "Vendor",
      "Details",
      "Amount",
      "Entry date",
      "Time",
      "Name",
      "Payment Status",
  ];
  const exportRows = filteredRecords.map(item => [
      item.entryNo,
      item.invoiceNo,
      item.invoiceDate,
      item.vendor,
      item.details,
      item.amount,
      item.entryDate,
      item.time,
      item.name,
      statusMeta[item.status].label,
  ]);

  const downloadBlob = (content: BlobPart, type: string, filename: string) => {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = filename;
    anchor.click();
    URL.revokeObjectURL(url);
  };

  const exportCsv = () => {
    const csvEscape = (value: string | number) => `"${String(value).replaceAll('"', '""')}"`;
    const csv = [exportHeaders, ...exportRows].map(row => row.map(csvEscape).join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "bill-register.csv";
    anchor.click();
    URL.revokeObjectURL(url);
    toast.success(`${filteredRecords.length} rows exported`);
  };

  const exportExcel = () => {
    const escapeHtml = (value: string | number) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
    const headerRow = `<tr>${exportHeaders.map(value => `<th>${escapeHtml(value)}</th>`).join("")}</tr>`;
    const bodyRows = exportRows.map(row => `<tr>${row.map(value => `<td>${escapeHtml(value)}</td>`).join("")}</tr>`).join("");
    const workbook = `<!doctype html><html><head><meta charset="utf-8"><style>body{font-family:Arial,sans-serif}table{border-collapse:collapse}th,td{border:1px solid #d9e0e8;padding:7px 9px;text-align:left;white-space:nowrap}th{background:#e8efff;color:#244caa;font-weight:700}td{color:#394657}</style></head><body><h2>Bill Register</h2><table><thead>${headerRow}</thead><tbody>${bodyRows}</tbody></table></body></html>`;
    downloadBlob(workbook, "application/vnd.ms-excel;charset=utf-8", `bill-register-${today()}.xls`);
    toast.success(`${filteredRecords.length} rows exported to Excel`);
  };

  const exportPdf = () => {
    const printWindow = window.open("", "_blank");
    if (!printWindow) {
      toast.error("Please allow pop-ups to export the register as PDF.");
      return;
    }
    const escapeHtml = (value: string | number) => String(value).replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
    const tableRows = exportRows.map(row => `<tr>${row.map(value => `<td>${escapeHtml(value)}</td>`).join("")}</tr>`).join("");
    const headerCells = exportHeaders.map(header => `<th>${escapeHtml(header)}</th>`).join("");
    printWindow.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Bill Register</title><style>@page{size:landscape;margin:12mm}*{box-sizing:border-box}body{font-family:Arial,sans-serif;color:#263448;margin:0}h1{font-size:22px;margin:0 0 4px}p{font-size:10px;color:#6f7d8e;margin:0 0 16px}table{width:100%;border-collapse:collapse;font-size:8px}th,td{border:1px solid #d9e0e8;padding:6px 5px;text-align:left;vertical-align:top}th{background:#e8efff;color:#244caa;font-weight:700}tr:nth-child(even) td{background:#fafbfd}.footer{margin-top:12px;font-size:9px;color:#7d8998}@media print{.footer{display:none}}</style></head><body><h1>Bill Register</h1><p>Exported ${escapeHtml(new Date().toLocaleString())} · ${filteredRecords.length} visible entries</p><table><thead><tr>${headerCells}</tr></thead><tbody>${tableRows}</tbody></table><div class="footer">Use your browser print dialog and choose “Save as PDF”.</div></body></html>`);
    printWindow.document.close();
    printWindow.focus();
    window.setTimeout(() => printWindow.print(), 300);
    toast.success("PDF print dialog opened");
  };

  return (
    <div className="app-shell">
      <aside className={`sidebar ${isMobileNavOpen ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><ReceiptText size={19} strokeWidth={2.2} /></div>
          <div>
            <div className="brand-name">bill entry</div>
            <div className="brand-caption">Organization ledger</div>
          </div>
          <button className="icon-button mobile-only" aria-label="Close navigation" onClick={() => setIsMobileNavOpen(false)}><X size={17} /></button>
        </div>

        <div className="workspace-switcher">
          <div className="workspace-avatar">MH</div>
          <div className="workspace-text"><strong>Milandhoo HC</strong><span>2026 register</span></div>
          <ChevronDown size={15} className="workspace-chevron" />
        </div>

        <nav className="nav-list" aria-label="Main navigation">
          <div className="nav-section-label">Workspace</div>
          <button className="nav-item active"><LayoutDashboard size={17} /><span>Bill register</span><span className="nav-count">{counts.all}</span></button>
          <button className="nav-item" onClick={() => { setFilter("pending"); setIsMobileNavOpen(false); }}><Clock3 size={17} /><span>Follow up</span><span className="nav-count nav-count-amber">{counts.pending}</span></button>
          <button className="nav-item" onClick={() => { setFilter("received"); setIsMobileNavOpen(false); }}><FileCheck2 size={17} /><span>Received</span></button>
          <div className="nav-section-label nav-section-spaced">Manage</div>
          <button className="nav-item"><Archive size={17} /><span>Archive</span></button>
          <button className="nav-item"><Settings2 size={17} /><span>Settings</span></button>
        </nav>

        <div className="sidebar-bottom">
          <div className="sync-card"><div className="sync-icon"><Zap size={15} /></div><div><strong>{billsQuery.isFetching ? "Syncing register…" : "All changes saved"}</strong><span>Shared workspace · every collaborator</span></div></div>
          <button className="profile-row profile-button" onClick={() => logout.mutate()} disabled={logout.isPending} title="Sign out"><div className="profile-avatar">{userInitials}</div><div><strong>{userName}</strong><span>{logout.isPending ? "Signing out…" : "Sign out"}</span></div><MoreHorizontal size={17} className="profile-more" /></button>
        </div>
      </aside>

      {isMobileNavOpen ? <button className="sidebar-backdrop" aria-label="Close navigation" onClick={() => setIsMobileNavOpen(false)} /> : null}

      <main className="main-content">
        <header className="topbar">
          <button className="icon-button mobile-only" aria-label="Open navigation" onClick={() => setIsMobileNavOpen(true)}><Menu size={19} /></button>
          <div className="breadcrumbs"><span>Workspace</span><ChevronRight size={14} /><strong>Bill register</strong></div>
          <div className="topbar-actions"><button className="top-icon-button" aria-label="Notifications"><Bell size={18} /><span className="notification-dot" /></button><div className="top-avatar">{userInitials}</div></div>
        </header>

        <div className="content-wrap">
          <section className="page-heading">
            <div><div className="eyebrow"><span className="eyebrow-dot" /> September 2026 register</div><h1>Bill register</h1><p>Everything received, at a glance.</p></div>
            <div className="heading-actions"><button className="secondary-button export-button" onClick={exportExcel}><FileSpreadsheet size={16} /> Excel</button><button className="secondary-button export-button" onClick={exportPdf}><FileText size={16} /> PDF</button><button className="secondary-button export-button" onClick={exportCsv}><Download size={16} /> CSV</button><button className="primary-button" onClick={() => openNewEntry()}><Plus size={17} /> Add bill</button></div>
          </section>

          <section className="summary-grid" aria-label="Register summary">
            <div className="summary-card summary-card-primary"><div className="summary-icon"><Files size={17} /></div><div className="summary-label">Total bills</div><div className="summary-value">{counts.all}</div><div className="summary-foot"><ArrowUpRight size={13} /> {formatAmount(totalAmount)} total value</div></div>
            <div className="summary-card"><div className="summary-icon summary-icon-green"><CheckCircle2 size={17} /></div><div className="summary-label">Received</div><div className="summary-value">{counts.received}</div><div className="summary-foot summary-foot-green">{counts.all ? Math.round((counts.received / counts.all) * 100) : 0}% of register</div></div>
            <div className="summary-card"><div className="summary-icon summary-icon-amber"><Clock3 size={17} /></div><div className="summary-label">Pending review</div><div className="summary-value">{counts.pending}</div><div className="summary-foot summary-foot-amber">Needs follow-up</div></div>
            <div className="summary-card"><div className="summary-icon summary-icon-coral"><CircleDashed size={17} /></div><div className="summary-label">Not received</div><div className="summary-value">{counts["not-received"]}</div><div className="summary-foot summary-foot-coral">Awaiting original bill</div></div>
          </section>

          <section className="scan-banner">
            <div className="scan-banner-icon"><ScanLine size={22} /></div>
            <div className="scan-banner-copy"><strong>Start with a scan</strong><span>Upload a bill photo and we’ll read the invoice fields for you to review.</span></div>
            <div className="scan-banner-actions"><input ref={cameraInputRef} className="visually-hidden" type="file" accept="image/*" capture="environment" onChange={runScan} /><input ref={photoInputRef} className="visually-hidden" type="file" accept="image/*" onChange={runScan} /><button className="scan-button" onClick={() => cameraInputRef.current?.click()}><ScanLine size={16} /> Take photo</button><button className="scan-button scan-button-secondary" onClick={() => photoInputRef.current?.click()}><Upload size={16} /> Choose photo</button><button className="banner-link" onClick={() => openNewEntry()}>Enter manually <ArrowUpRight size={14} /></button></div>
          </section>

          <section className="register-card">
            <div className="register-toolbar">
              <div className="register-title"><div className="section-icon"><ReceiptText size={17} /></div><div><h2>Bill entries</h2><span>{filteredRecords.length} visible of {records.length} records</span></div></div>
              <div className="toolbar-actions"><div className="search-box"><Search size={16} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search bills..." aria-label="Search bills" />{search ? <button className="clear-search" onClick={() => setSearch("")} aria-label="Clear search"><X size={14} /></button> : null}</div><button className="filter-button"><SlidersHorizontal size={16} /> <span className="filter-button-label">Filters</span></button></div>
            </div>
            <div className="filter-tabs" role="tablist" aria-label="Filter bills by status">
              {(["all", "received", "pending", "not-received"] as FilterKey[]).map(key => <button key={key} className={`filter-tab ${filter === key ? "active" : ""}`} onClick={() => setFilter(key)} role="tab" aria-selected={filter === key}>{key === "all" ? "All bills" : statusMeta[key].label}<span>{counts[key]}</span></button>)}
            </div>
            <div className="table-wrap">
              <table className="ledger-table">
                <thead><tr><th className="entry-col">Entry no.</th><th>Invoice no.</th><th>Invoice date</th><th className="vendor-col">Vendor</th><th className="details-col">Details</th><th>Amount</th><th>Entry date</th><th>Time</th><th>Name</th><th>Payment status</th><th className="action-col"><span className="visually-hidden">Actions</span></th></tr></thead>
                <tbody>
                  {filteredRecords.map(item => <tr key={item.id} onClick={() => openEditEntry(item)}>
                    <td className="entry-number">{item.entryNo}</td><td className="invoice-number">{item.invoiceNo}</td><td className="date-cell">{formatDate(item.invoiceDate)}</td><td className="vendor-cell"><strong>{item.vendor}</strong></td><td className="details-cell">{item.details}</td><td className="amount-cell">{formatAmount(item.amount)}</td><td className="date-cell">{formatDate(item.entryDate)}</td><td className="time-cell">{item.time}</td><td className="name-cell"><span className="mini-avatar">{item.name.split(" ").map(part => part[0]).join("").slice(0, 2)}</span>{item.name}</td><td onClick={event => event.stopPropagation()}><select className={`status-select ${statusMeta[item.status].tone}`} value={item.status} onChange={event => changeStatus(item.id, event.target.value as BillStatus)} aria-label={`Change status for ${item.entryNo}`}><option value="received">Received</option><option value="pending">Pending</option><option value="not-received">Not received</option></select></td><td><div className="row-actions"><button className="row-more" onClick={event => { event.stopPropagation(); openEditEntry(item); }} aria-label={`Edit ${item.entryNo}`}><MoreHorizontal size={17} /></button><button className="row-delete" onClick={event => { event.stopPropagation(); deleteEntryById(item.id); }} aria-label={`Delete ${item.entryNo}`} title="Delete entry"><Trash2 size={15} /></button></div></td>
                  </tr>)}
                  {filteredRecords.length === 0 ? <tr><td colSpan={11}><div className="empty-state"><Search size={25} /><strong>No bills match this view</strong><span>Try a different search or add a new bill entry.</span><button className="secondary-button" onClick={() => { setSearch(""); setFilter("all"); }}>Clear filters</button></div></td></tr> : null}
                </tbody>
              </table>
            </div>
            <div className="register-footer"><span>Showing {filteredRecords.length} of {records.length} bill entries</span><div className="pagination"><button className="pagination-button" aria-label="Previous page"><ChevronLeft size={15} /></button><span className="page-number active">1</span><button className="pagination-button" aria-label="Next page"><ChevronRight size={15} /></button></div></div>
          </section>
        </div>
      </main>

      {isFormOpen ? <div className="modal-layer" role="dialog" aria-modal="true" aria-labelledby="entry-form-title">
        <button className="modal-scrim" aria-label="Close entry form" onClick={closeForm} />
        <section className="entry-sheet">
          <div className="sheet-header"><div><div className="sheet-kicker">{editingId ? "Edit register row" : "New register row"}</div><h2 id="entry-form-title">{isScanning ? "Reading your bill" : editingId ? `Edit ${draft.entryNo}` : "Add bill entry"}</h2></div><button className="icon-button" onClick={closeForm} aria-label="Close form"><X size={18} /></button></div>
          {isScanning ? <div className="scan-progress"><div className="scan-animation"><FileScan size={28} /><span className="scan-line" /></div><strong>Scanning bill details...</strong><span>We’re reading the invoice number, date, vendor, and amount.</span><div className="progress-track"><div className="progress-bar" /></div></div> : <form onSubmit={saveEntry}>
            <div className="number-callout"><div className="number-callout-icon"><Sparkles size={15} /></div><div><span>Automatic entry number</span><strong>{draft.entryNo}</strong></div><span className="number-callout-note">Next in sequence</span></div>
            {scanNotes ? <div className="scan-notes"><FileCheck2 size={14} /><span>{scanNotes}. Check every field before saving.</span></div> : null}
            <div className="form-grid"><Field label="Invoice number"><input className="form-input" value={draft.invoiceNo} onChange={event => updateDraft("invoiceNo", event.target.value)} placeholder="e.g. C 2258" autoFocus /></Field><Field label="Invoice date"><div className="input-with-icon"><CalendarDays size={16} /><input className="form-input" type="date" value={draft.invoiceDate} onChange={event => updateDraft("invoiceDate", event.target.value)} /></div></Field><Field label="Vendor" className="field-span-2"><input className="form-input" value={draft.vendor} onChange={event => updateDraft("vendor", event.target.value)} placeholder="Organization or supplier name" /></Field><Field label="Details" className="field-span-2"><textarea className="form-input form-textarea" value={draft.details} onChange={event => updateDraft("details", event.target.value)} placeholder="What is this bill for?" rows={3} /></Field><Field label="Amount"><div className="amount-input"><span>MVR</span><input className="form-input" type="number" min="0" value={draft.amount || ""} onChange={event => updateDraft("amount", Number(event.target.value))} placeholder="0" /></div></Field><Field label="Payment status"><select className="form-input" value={draft.status} onChange={event => updateDraft("status", event.target.value as BillStatus)}><option value="received">Received</option><option value="pending">Pending</option><option value="not-received">Not received</option></select></Field><Field label="Entry date"><input className="form-input" type="date" value={draft.entryDate} onChange={event => updateDraft("entryDate", event.target.value)} /></Field><Field label="Time"><input className="form-input" type="time" value={draft.time} onChange={event => updateDraft("time", event.target.value)} /></Field><Field label="Entered by" className="field-span-2"><div className="input-with-icon"><UserRound size={16} /><input className="form-input" value={draft.name} onChange={event => updateDraft("name", event.target.value)} placeholder="Team member name" /></div></Field></div>
            <div className="sheet-footer">{editingId ? <button type="button" className="delete-button" onClick={deleteEntry}><Trash2 size={15} /> Delete entry</button> : null}<button type="button" className="secondary-button" onClick={closeForm}>Cancel</button><button type="submit" className="primary-button"><Check size={17} /> {editingId ? "Save changes" : "Save bill entry"}</button></div>
          </form>}
        </section>
      </div> : null}
    </div>
  );
}
