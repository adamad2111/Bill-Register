# Bill Entry

## Implementation approach

Build a single-page React bill register backed by a local persisted ledger for fast entry and reliable offline-like interaction in Preview. The user-facing workflow mirrors the supplied Milandhoo HC Bill Entry spreadsheet: entry number, invoice number, invoice date, vendor, details, amount, entry date, time, name, and payment status. New records receive a sequential `NN/YYYY` entry number automatically. The scan action accepts a bill photo, sends it to the server-side managed vision model, and returns structured invoice fields with a confidence note before the user reviews and saves.

The page keeps the table and status controls as the primary surface, with a compact entry drawer/modal for add/edit. Search and status tabs filter the ledger; status can be changed inline; export produces CSV, Excel-compatible `.xls`, or a print-formatted PDF flow matching the spreadsheet columns and current filter. Manus OAuth gates the register, and protected tRPC procedures read and mutate a project-scoped MySQL `bill_entries` table so every signed-in collaborator sees the same register. The page refreshes shared data periodically and on window focus, while the server allocates the next entry number and persists create, edit, status, and delete operations. The server-side extractor supports alternate labeled tax-invoice layouts, including Maldives Gas-style documents: bill or tax invoice numbers and dates, company headers, item details, grand totals, prepared/received-by dates and times, named staff, and explicit received or paid indications are normalized into the spreadsheet fields for review before saving.

## Project structure

- `client/src/pages/Home.tsx`: authenticated shared register page, vision scan flow, entry form, filters, CSV/Excel/PDF export, and tRPC-backed mutations.
- `client/src/index.css`: visual system, responsive layout, iOS-inspired surfaces, table, modal, and status styling.
- `client/src/App.tsx`: application shell and route.
- `server/routers.ts`: authenticated bill list, create, edit, status, and delete procedures.
- `server/db.ts` and `drizzle/schema.ts`: managed MySQL access, shared bill entries, and one-time initial seed setup.
- `public/manus-routes.json`: route manifest for the single-page app.
- `plan.md` and `TODO.md`: product and delivery record.

## Design

### Style options

- **Quiet iOS Operations** — 0.06 probability: a soft graphite canvas, frosted white cards, cobalt action color, and familiar system-like density.
- **Warm Ledger Studio** — 0.04 probability: cream paper tones, ink black, and coral approval accents.
- **Midnight Control Room** — 0.03 probability: dark navy surfaces, cyan status lights, and dense monitoring panels.

Chosen: **Quiet iOS Operations**.

### Design movement

A contemporary iOS productivity surface translated into an operations ledger: translucent layers, crisp type, quiet separators, and bold, legible status color.

### Core principles

1. The register is the product: the spreadsheet-shaped table always gets the most visual weight.
2. Data entry should feel calm: one clear primary action, prefilled form fields, and visible next-number logic.
3. Status is a scanning language: received, pending, and not received are differentiated with color and concise labels.
4. Every control is useful at a glance: no decorative dashboard charts that compete with the register.

### Color philosophy

Use a cool fog background and white glass surfaces to make the dense table feel light. Cobalt is the signature brand color for actions and focus. Mint, amber, and coral indicate workflow state rather than decoration. Charcoal text keeps long invoice and vendor strings readable.

### Layout paradigm

A left rail anchors the organization context; the main register sits in a wide canvas with a compact header, four summary cards, a scan callout, and a bordered ledger. The add/edit form appears as a right-side sheet on desktop and a bottom sheet on small screens.

### Signature elements

- A small cobalt rounded-square mark with a receipt line icon.
- Frosted card surfaces with subtle inner highlights.
- Status pills with small leading dots and restrained semantic color.

### Interaction philosophy

Primary actions use a slight lift and color shift on hover. Form fields use a blue focus ring. Scanning is a short, visible state change rather than an opaque upload. Inline status updates remain close to the row being edited.

### Animation

Use 160–220ms ease-out transitions for hover, panel entry, and chip changes. The scan progress indicator uses a gentle indeterminate shimmer. Avoid continuous motion elsewhere.

### Typography system

Use Inter / system UI with a strong 12–13px eyebrow, 15–16px body, 22px section headings, and 30px page title. Numbers in summary cards and amounts in the ledger use tabular numerals.

### Brand essence

A calm, scan-first bill register for organization teams who need to know what arrived, what is pending, and what needs follow-up. Personality: precise, reassuring, current.

### Brand voice

Short, practical, and reassuring. Example lines: “Everything received, at a glance.” and “Scan a bill to start a clean entry.”

### Wordmark & logo

A compact receipt mark: two offset rounded rectangles with a single horizontal line, paired with a lower-case `bill entry` wordmark.

### Signature brand color

Cobalt `#3569E8`, used only for primary actions, active navigation, and focus states.
