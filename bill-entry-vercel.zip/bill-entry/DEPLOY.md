# Deploy: Supabase (database) + Vercel (hosting)

1. Supabase: open your project > Connect > copy the **Transaction pooler** connection string (port 6543) and insert your database password.
2. Push this folder to GitHub, then import the repo in Vercel (settings come from vercel.json).
3. Vercel > Settings > Environment Variables: DATABASE_URL, SESSION_SECRET, SIGNUP_CODE, ANTHROPIC_API_KEY (see .env.example).
4. Deploy, open the site, choose "Create an account" and enter SIGNUP_CODE.
Tables, row-level security and example rows are created automatically on the first request.
