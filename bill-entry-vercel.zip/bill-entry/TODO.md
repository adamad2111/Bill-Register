# TODO

## Deliver a spreadsheet-shaped bill register

- Show the bill register with the supplied spreadsheet fields: Entry no., Invoice no., Invoice date, Vendor, Details, Amount, Entry date, Time, Name, and Payment Status.
- Keep the register readable with seeded example rows matching the supplied Milandhoo HC structure and organization context.
- Show summary counts for all bills, received, pending, and not received.
- Store bill entries in shared project cloud storage instead of browser-local storage so multiple signed-in people see the same register.
- Keep automatic entry numbering server-backed so new entries saved by different collaborators receive unique sequential entry numbers.

## Deliver scan-assisted bill entry

- Provide a visible Scan bill action that accepts a bill photo from file upload or mobile camera capture.
- Provide separate Take photo and Choose photo actions so an already-taken bill image can be scanned from the device gallery.
- Send the uploaded photo to the server-side vision extractor, return invoice number, date, vendor, details, amount, entry date, time, name, status, and confidence, and prefill the entry form for user review.
- Support alternate labeled tax-invoice layouts such as Maldives Gas: map Bill No / Invoice No / Tax Invoice number, Bill Date / Invoice Date, company header, Item Details / Particulars / Description, Grand Total / Total / Amount Inc. GST, Prepared by, and Goods Received by into the spreadsheet fields.
- Use Goods Received by date/time when present, otherwise Prepared by date/time; mark received only for an explicit received signature, date, stamp, or paid indication, otherwise keep Pending unless explicitly Not received.
- Show a clear error when the photo is unsupported, too large, unreadable, or missing required bill content.
- Allow manual entry when the user does not scan a bill.

## Deliver automatic numbering and editing

- Automatically generate the next sequential `NN/YYYY` entry number for new entries.
- Save new entries, edit existing entries, and keep data available after refresh through browser persistence.
- Allow payment status to be set to received, not received, or pending in the entry form and changed inline from the register.
- Provide a Delete entry action in the edit sheet and directly on each entered bill row, with a confirmation prompt before removing a saved bill.

## Deliver review and export controls

- Filter by all, received, pending, and not received.
- Search by invoice number, vendor, details, or entry number.
- Export the visible ledger to CSV, Excel, or PDF using the spreadsheet column order.
- Excel export downloads an Excel-compatible workbook containing the currently filtered rows.
- PDF export opens a formatted landscape print view so the user can choose Save as PDF.

## Deliver authenticated collaboration

- Require a signed-in Manus account before showing the shared register or allowing bill data access.
- Allow authenticated collaborators to create, edit, change status, and delete entries in the same shared register.
- Show the signed-in collaborator and shared-sync state, provide sign out, and refresh shared data on window focus and periodically.

## Deliver the iOS-inspired interface

- Provide a modern, responsive interface with a left navigation rail, frosted cards, cobalt primary actions, and semantic status pills.
- Keep the primary entry workflow usable on both desktop and mobile widths.
