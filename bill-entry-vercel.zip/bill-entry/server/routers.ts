import { TRPCError } from "@trpc/server";
import { COOKIE_NAME } from "../shared/const.js";
import { SESSION_MS, createSessionToken, hashPassword, verifyPassword } from "./_core/auth.js";
import { getSessionCookieOptions } from "./_core/cookies.js";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc.js";
import * as db from "./db.js";
import { z } from "zod";

const billStatus = z.enum(["received", "pending", "not-received"]);

const billFields = z.object({
  invoiceNo: z.string().trim().min(1).max(128),
  invoiceDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  vendor: z.string().trim().min(1),
  details: z.string().trim().max(2000),
  amount: z.number().int().min(0),
  entryDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/),
  time: z.string().regex(/^\d{2}:\d{2}$/),
  name: z.string().trim().min(1).max(160),
  status: billStatus,
});

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  auth: router({
    me: publicProcedure.query(({ ctx }) => (ctx.user ? { id: ctx.user.id, name: ctx.user.name, email: ctx.user.email, role: ctx.user.role } : null)),
    register: publicProcedure
      .input(z.object({
        name: z.string().trim().min(1).max(160),
        email: z.string().trim().toLowerCase().email().max(320),
        password: z.string().min(8).max(200),
        inviteCode: z.string(),
      }))
      .mutation(async ({ input, ctx }) => {
        const expected = process.env.SIGNUP_CODE;
        if (!expected || input.inviteCode.trim() !== expected) throw new TRPCError({ code: "FORBIDDEN", message: "That invite code is not valid." });
        if (await db.getUserByEmail(input.email)) throw new TRPCError({ code: "CONFLICT", message: "An account with this email already exists." });
        const user = await db.createLocalUser({ email: input.email, name: input.name, passwordHash: await hashPassword(input.password) });
        ctx.res.cookie(COOKIE_NAME, await createSessionToken(user.openId), { ...getSessionCookieOptions(ctx.req), maxAge: SESSION_MS });
        return { success: true } as const;
      }),
    login: publicProcedure
      .input(z.object({ email: z.string().trim().toLowerCase().email(), password: z.string().min(1).max(200) }))
      .mutation(async ({ input, ctx }) => {
        const user = await db.getUserByEmail(input.email);
        if (!(await verifyPassword(input.password, user?.passwordHash)) || !user) throw new TRPCError({ code: "UNAUTHORIZED", message: "Incorrect email or password." });
        ctx.res.cookie(COOKIE_NAME, await createSessionToken(user.openId), { ...getSessionCookieOptions(ctx.req), maxAge: SESSION_MS });
        return { success: true } as const;
      }),
    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie(COOKIE_NAME, { ...getSessionCookieOptions(ctx.req), maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  bills: router({
    list: protectedProcedure.query(() => db.listBillEntries()),
    create: protectedProcedure
      .input(billFields)
      .mutation(({ input, ctx }) => db.createBillEntry({ ...input, createdByOpenId: ctx.user.openId })),
    update: protectedProcedure
      .input(z.object({ id: z.string().min(1), fields: billFields }))
      .mutation(({ input }) => db.updateBillEntry(input.id, input.fields)),
    changeStatus: protectedProcedure
      .input(z.object({ id: z.string().min(1), status: billStatus }))
      .mutation(({ input }) => db.updateBillEntry(input.id, { status: input.status })),
    delete: protectedProcedure
      .input(z.object({ id: z.string().min(1) }))
      .mutation(({ input }) => db.deleteBillEntry(input.id)),
  }),
});

export type AppRouter = typeof appRouter;
