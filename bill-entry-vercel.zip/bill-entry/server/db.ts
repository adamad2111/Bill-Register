import { eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/postgres-js";
import postgres from "postgres";
import { nanoid } from "nanoid";
import { BillEntry, billEntries, billRegisterMeta, InsertBillEntry, users } from "../drizzle/schema.js";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      // prepare:false is required for Supabase's transaction pooler (port 6543); max:1 suits serverless.
      _db = drizzle(postgres(process.env.DATABASE_URL, { prepare: false, max: 1 }));
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const [user] = await db.select().from(users).where(eq(users.email, email)).limit(1);
  return user;
}

export async function createLocalUser(input: { email: string; name: string; passwordHash: string }) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  const openId = `local-${nanoid(21)}`;
  await db.insert(users).values({ openId, email: input.email, name: input.name, passwordHash: input.passwordHash, loginMethod: "password" });
  const [user] = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return user;
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

const seedBillEntries: InsertBillEntry[] = [
  { id: "bill-001", entryNo: "001/2026", invoiceNo: "C 2258", invoiceDate: "2026-09-02", vendor: "All H Maldives Pvt. Ltd.", details: "FND/MLE PD male dhiumah", amount: 1464, entryDate: "2026-09-02", time: "09:40", name: "Aminath Nafha", status: "not-received", createdByOpenId: "system-seed" },
  { id: "bill-002", entryNo: "002/2026", invoiceNo: "E2BUSM", invoiceDate: "2026-09-02", vendor: "Maldivian", details: "MLE/FND PD ge dhathuru", amount: 1464, entryDate: "2026-09-02", time: "09:40", name: "Aminath Nafha", status: "not-received", createdByOpenId: "system-seed" },
  { id: "bill-003", entryNo: "003/2026", invoiceNo: "INV-8841", invoiceDate: "2026-09-04", vendor: "Island Office Supplies", details: "Stationery and printer consumables", amount: 3880, entryDate: "2026-09-04", time: "11:15", name: "Hassan Shiyam", status: "received", createdByOpenId: "system-seed" },
  { id: "bill-004", entryNo: "004/2026", invoiceNo: "MVR-0926", invoiceDate: "2026-09-07", vendor: "Samann Grand", details: "Official meeting refreshments", amount: 7250, entryDate: "2026-09-07", time: "14:05", name: "Aminath Nafha", status: "pending", createdByOpenId: "system-seed" },
  { id: "bill-005", entryNo: "005/2026", invoiceNo: "FUEL-4439", invoiceDate: "2026-09-09", vendor: "State Trading Organisation", details: "Generator fuel supply", amount: 12900, entryDate: "2026-09-09", time: "15:22", name: "Mohamed Rishwan", status: "received", createdByOpenId: "system-seed" },
  { id: "bill-006", entryNo: "006/2026", invoiceNo: "WEB-183", invoiceDate: "2026-09-11", vendor: "Dhiraagu", details: "Monthly broadband and landline", amount: 2140, entryDate: "2026-09-11", time: "10:10", name: "Hassan Shiyam", status: "pending", createdByOpenId: "system-seed" },
];

export async function ensureSharedRegister() {
  const db = await getDb();
  if (!db) return false;

  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS users (
      "id" serial PRIMARY KEY,
      "openId" varchar(64) NOT NULL UNIQUE,
      "name" text,
      "email" varchar(320) UNIQUE,
      "loginMethod" varchar(64),
      "passwordHash" varchar(255),
      "role" varchar(16) NOT NULL DEFAULT 'user',
      "createdAt" timestamp NOT NULL DEFAULT now(),
      "updatedAt" timestamp NOT NULL DEFAULT now(),
      "lastSignedIn" timestamp NOT NULL DEFAULT now()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS bill_entries (
      "id" varchar(36) PRIMARY KEY,
      "entryNo" varchar(16) NOT NULL UNIQUE,
      "invoiceNo" varchar(128) NOT NULL,
      "invoiceDate" varchar(10) NOT NULL,
      "vendor" text NOT NULL,
      "details" text NOT NULL,
      "amount" integer NOT NULL DEFAULT 0,
      "entryDate" varchar(10) NOT NULL,
      "time" varchar(5) NOT NULL,
      "name" varchar(160) NOT NULL,
      "status" varchar(16) NOT NULL DEFAULT 'pending',
      "createdByOpenId" varchar(64) NOT NULL,
      "createdAt" timestamp NOT NULL DEFAULT now(),
      "updatedAt" timestamp NOT NULL DEFAULT now()
    )
  `);
  await db.execute(sql`
    CREATE TABLE IF NOT EXISTS bill_register_meta (
      "metaKey" varchar(64) PRIMARY KEY,
      "metaValue" text NOT NULL
    )
  `);
  // Supabase exposes the public schema through its REST API. Row Level Security with no
  // policies blocks that route; this server connects as the database owner and is unaffected.
  for (const table of ["users", "bill_entries", "bill_register_meta"]) {
    await db.execute(sql.raw(`ALTER TABLE ${table} ENABLE ROW LEVEL SECURITY`));
  }

  const [seedMarker] = await db.select({ metaKey: billRegisterMeta.metaKey }).from(billRegisterMeta).where(eq(billRegisterMeta.metaKey, "seed-v1")).limit(1);
  if (!seedMarker) {
    await db.insert(billEntries).values(seedBillEntries).onConflictDoNothing();
    await db.insert(billRegisterMeta).values({ metaKey: "seed-v1", metaValue: "Initial shared register rows" });
  }
  return true;
}

export async function listBillEntries(): Promise<BillEntry[]> {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  return db.select().from(billEntries);
}

const currentYear = () => new Date().getFullYear();

const nextEntryNo = (entries: Pick<BillEntry, "entryNo">[]) => {
  const year = currentYear();
  const max = entries.reduce((highest, entry) => {
    const [number, entryYear] = entry.entryNo.split("/");
    if (Number(entryYear) !== year) return highest;
    return Math.max(highest, Number(number) || 0);
  }, 0);
  return `${String(max + 1).padStart(3, "0")}/${year}`;
};

const isDuplicateEntryNo = (error: unknown) => {
  const code = (error as { code?: string })?.code;
  const message = error instanceof Error ? error.message : String(error);
  return code === "23505" || message.includes("duplicate key");
};

export async function createBillEntry(input: Omit<InsertBillEntry, "id" | "entryNo">) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const existing = await db.select({ entryNo: billEntries.entryNo }).from(billEntries);
    const entryNo = nextEntryNo(existing);
    const record = { ...input, id: nanoid(16), entryNo } satisfies InsertBillEntry;
    try {
      await db.insert(billEntries).values(record);
      const [created] = await db.select().from(billEntries).where(eq(billEntries.id, record.id)).limit(1);
      if (!created) throw new Error("Created bill entry could not be read back");
      return created;
    } catch (error) {
      if (!isDuplicateEntryNo(error) || attempt === 4) throw error;
    }
  }

  throw new Error("Could not allocate a unique entry number");
}

export async function updateBillEntry(id: string, input: Partial<Omit<InsertBillEntry, "id" | "entryNo" | "createdByOpenId">>) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.update(billEntries).set({ ...input, updatedAt: new Date() }).where(eq(billEntries.id, id));
  const [updated] = await db.select().from(billEntries).where(eq(billEntries.id, id)).limit(1);
  return updated;
}

export async function deleteBillEntry(id: string) {
  const db = await getDb();
  if (!db) throw new Error("Database is not available");
  await db.delete(billEntries).where(eq(billEntries.id, id));
}
