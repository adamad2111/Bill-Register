import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { appRouter } from "../routers.js";
import { createContext } from "./context.js";
import { authenticateRequest } from "./auth.js";
import { extractBillFromPhoto } from "../billScan.js";
import { ensureSharedRegister } from "../db.js";

export async function createApp() {
  await ensureSharedRegister();
  const app = express();
  // Configure body parser with larger size limit for file uploads
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  const requireAuth = async (req: express.Request, res: express.Response, next: express.NextFunction) => {
    if (await authenticateRequest(req)) return next();
    res.status(401).json({ error: "Please sign in." });
  };
  app.post("/api/scan-bill", requireAuth, async (req, res) => {
    try {
      const dataUrl = typeof req.body?.dataUrl === "string" ? req.body.dataUrl : "";
      if (!dataUrl.startsWith("data:image/")) {
        return res.status(400).json({ error: "Please upload a bill photo in JPG, PNG, or WebP format." });
      }
      if (dataUrl.length > 16_000_000) {
        return res.status(413).json({ error: "That photo is too large. Please upload an image under 12 MB." });
      }
      const bill = await extractBillFromPhoto(dataUrl);
      return res.json({ bill });
    } catch (error) {
      console.error("[Bill scan] Failed to extract bill details:", error);
      return res.status(502).json({ error: "We couldn’t read this bill photo. Try a clearer, well-lit photo with the full bill visible." });
    }
  });
  // tRPC API
  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );
  return app;
}

async function startServer() {
  const app = await createApp();
  const server = createServer(app);

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

if (process.env.VERCEL !== "1") {
  startServer().catch(error => { console.error(error); process.exit(1); });
}
