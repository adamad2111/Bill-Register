
export type ScannedBill = {
  invoiceNo: string;
  invoiceDate: string;
  vendor: string;
  details: string;
  amount: number;
  entryDate: string;
  time: string;
  name: string;
  status: "received" | "pending" | "not-received";
  confidence: "high" | "medium" | "low";
  notes: string;
};


const cleanDate = (value: unknown) => {
  const raw = String(value ?? "").trim();
  if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) return raw;
  const match = raw.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})/);
  if (!match) return "";
  const [, first, second, yearValue] = match;
  const year = yearValue.length === 2 ? `20${yearValue}` : yearValue;
  const day = Number(first) > 12 ? first : second;
  const month = Number(first) > 12 ? second : first;
  return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
};

const cleanAmount = (value: unknown) => {
  if (typeof value === "number" && Number.isFinite(value)) return Math.max(0, value);
  const normalized = String(value ?? "").replace(/[^\d.,-]/g, "").replace(/,(?=\d{3}(?:\D|$))/g, "").replace(/,/g, ".");
  const amount = Number.parseFloat(normalized);
  return Number.isFinite(amount) ? Math.max(0, amount) : 0;
};

const cleanTime = (value: unknown) => {
  const match = String(value ?? "").match(/(\d{1,2}):(\d{2})/);
  if (!match) return "";
  return `${match[1].padStart(2, "0")}:${match[2]}`;
};

const normalizeStatus = (value: unknown): ScannedBill["status"] => {
  const status = String(value ?? "").toLowerCase();
  if (status.includes("received") && !status.includes("not")) return "received";
  if (status.includes("not")) return "not-received";
  return "pending";
};

const parseJson = (content: string) => {
  const fenced = content.match(/```(?:json)?\s*([\s\S]*?)\s*```/i)?.[1] ?? content;
  const trimmed = fenced.trim();
  const start = trimmed.indexOf("{");
  if (start < 0) throw new Error(`The scan did not return structured bill details: ${content.slice(0, 300)}`);
  let depth = 0;
  let quoted = false;
  let escaped = false;
  for (let index = start; index < trimmed.length; index += 1) {
    const character = trimmed[index];
    if (quoted) {
      if (escaped) escaped = false;
      else if (character === "\\") escaped = true;
      else if (character === '"') quoted = false;
      continue;
    }
    if (character === '"') {
      quoted = true;
      continue;
    }
    if (character === "{") depth += 1;
    if (character === "}") {
      depth -= 1;
      if (depth === 0) return JSON.parse(trimmed.slice(start, index + 1)) as Record<string, unknown>;
    }
  }
  throw new Error(`The scan did not return a complete bill object: ${content.slice(0, 300)}`);
};

const SYSTEM_PROMPT = "You extract bill and invoice fields from photos. Return only valid JSON. Never invent a value: use an empty string for unreadable text and 0 for an unreadable amount. Dates must be yyyy-mm-dd when confidently readable. Keep details concise and preserve the original language where possible.";
const SCAN_PROMPT = `Read the single bill or invoice in this photo. Return one JSON object only, never an array and never multiple rows. Use exactly these JSON keys: invoiceNo, invoiceDate, vendor, details, amount, entryDate, time, name, status, confidence, notes. Support many invoice layouts, including Maldives Gas tax invoices. Map Bill No / Invoice No / Tax Invoice number to invoiceNo; Bill Date / Invoice Date to invoiceDate; the company header to vendor; Item Details / Particulars / Description to details; Grand Total / Total / Amount Inc. GST to amount. For the spreadsheet entry fields, use the Goods Received by date/time when present; otherwise use the Prepared by Date/Time. Use the named person under Prepared by or Goods Received by as name. Dates must be yyyy-mm-dd and times must be HH:mm. Status should be "received" when a received signature, received date, stamp, or clear paid/received indication is present; otherwise use "pending". Use "not-received" only when the document explicitly says it was not received. confidence is high, medium, or low. notes should mention fields that were unclear. If the photo is a spreadsheet or contains multiple bills, extract the first complete bill row only.`;

export async function extractBillFromPhoto(dataUrl: string): Promise<ScannedBill> {
  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) throw new Error("ANTHROPIC_API_KEY is not set");
  const match = dataUrl.match(/^data:(image\/(?:jpeg|png|webp|gif));base64,(.+)$/);
  if (!match) throw new Error("Unsupported image type");
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "content-type": "application/json", "x-api-key": key, "anthropic-version": "2023-06-01" },
    body: JSON.stringify({
      model: process.env.ANTHROPIC_MODEL || "claude-sonnet-5-5",
      max_tokens: 2048,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: [
        { type: "image", source: { type: "base64", media_type: match[1], data: match[2] } },
        { type: "text", text: SCAN_PROMPT },
      ] }],
    }),
  });
  if (!response.ok) throw new Error(`Anthropic API ${response.status}: ${(await response.text()).slice(0, 300)}`);
  const data = (await response.json()) as { content?: { type: string; text?: string }[] };
  const content = data.content?.find(block => block.type === "text")?.text;
  if (typeof content !== "string" || !content.trim()) throw new Error("The scan returned no readable details.");
  const raw = parseJson(content);
  return {
    invoiceNo: String(raw.invoiceNo ?? "").trim(),
    invoiceDate: cleanDate(raw.invoiceDate),
    vendor: String(raw.vendor ?? "").trim(),
    details: String(raw.details ?? "").trim(),
    amount: cleanAmount(raw.amount),
    entryDate: cleanDate(raw.entryDate),
    time: cleanTime(raw.time),
    name: String(raw.name ?? "").trim(),
    status: normalizeStatus(raw.status),
    confidence: ["high", "medium", "low"].includes(String(raw.confidence)) ? (raw.confidence as ScannedBill["confidence"]) : "low",
    notes: String(raw.notes ?? "").trim(),
  };
}
